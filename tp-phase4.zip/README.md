# communityfund
CSC309 Project.
Powered using a mix of Django, Sqlite, and Bootstrap.
